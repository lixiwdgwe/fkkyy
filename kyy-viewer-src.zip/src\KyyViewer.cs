﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace KyyViewer
{
    static class Paths
    {
        public static string ExeDir = Path.GetDirectoryName(Application.ExecutablePath);
        public static string Root = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KyyAnswers");
        public static string Pkg = Path.Combine(Root, "pkg");
        public static string Ans = Path.Combine(Root, "answers");
        public static string ClientExe
        {
            get
            {
                string[] c = {
                    @"C:\Program Files (x86)\口语易\kyyclient.exe",
                    @"C:\Program Files\口语易\kyyclient.exe"
                };
                foreach (string p in c) if (File.Exists(p)) return p;
                return null;
            }
        }
        public static string[] SearchDirs()
        {
            var list = new List<string>();
            list.Add(Path.Combine(ExeDir, "pkg"));
            string parent = Path.GetDirectoryName(ExeDir.TrimEnd('\\'));
            if (!string.IsNullOrEmpty(parent)) list.Add(Path.Combine(parent, "pkg"));
            list.Add(Pkg);
            list.Add(@"C:\Program Files (x86)\口语易\unit_zip_dl");
            return list.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        }
        public static void Ensure()
        {
            Directory.CreateDirectory(Pkg);
            Directory.CreateDirectory(Ans);
        }
    }

    class Question
    {
        public int No;
        public string Name;
        public double Score;
        public string Text = "";
        public string Answer = "";
        public List<string> Variants = new List<string>();
        public string Keypoints = "";
        public string Head { get { return string.IsNullOrEmpty(Name) ? ("第 " + No + " 题") : Name; } }
    }

    class Part
    {
        public string Name;
        public double Score;
        public List<string> Context = new List<string>();
        public List<Question> Questions = new List<Question>();
    }

    class Paper
    {
        public int Id;
        public string Name;
        public string Total;
        public string Dir;
        public string Key = "";
        public List<Part> Parts = new List<Part>();

        public IEnumerable<Question> AllQuestions()
        {
            foreach (Part p in Parts) foreach (Question q in p.Questions) yield return q;
        }
    }

    static class PaperStore
    {
        static JavaScriptSerializer Ser()
        {
            var s = new JavaScriptSerializer();
            s.MaxJsonLength = int.MaxValue;
            return s;
        }

        public static Dictionary<string, object> Parse(string path)
        {
            string json = File.ReadAllText(path, Encoding.UTF8);
            return (Dictionary<string, object>)Ser().DeserializeObject(json);
        }

        static string S(Dictionary<string, object> d, string k)
        {
            object v; if (d != null && d.TryGetValue(k, out v) && v != null) return Convert.ToString(v, CultureInfo.InvariantCulture);
            return "";
        }
        static double D(Dictionary<string, object> d, string k)
        {
            object v; double r;
            if (d != null && d.TryGetValue(k, out v) && v != null &&
                double.TryParse(Convert.ToString(v, CultureInfo.InvariantCulture), NumberStyles.Any, CultureInfo.InvariantCulture, out r)) return r;
            return 0;
        }
        static object[] A(Dictionary<string, object> d, string k)
        {
            object v;
            if (d != null && d.TryGetValue(k, out v) && v is object[]) return (object[])v;
            return new object[0];
        }

        public static string CleanName(string n)
        {
            n = n ?? "";
            while (n.StartsWith("【"))
            {
                int i = n.IndexOf('】');
                if (i < 0) break;
                n = n.Substring(i + 1);
            }
            return n.Trim();
        }

        public static string StripTags(string html)
        {
            string s = System.Text.RegularExpressions.Regex.Replace(html, "<script[\\s\\S]*?</script>", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            s = System.Text.RegularExpressions.Regex.Replace(s, "<style[\\s\\S]*?</style>", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            s = System.Text.RegularExpressions.Regex.Replace(s, "<[^>]+>", "\n");
            s = WebUtility.HtmlDecode(s);
            var lines = new List<string>();
            foreach (string raw in s.Split('\n'))
            {
                string t = raw.Trim();
                if (t.Length == 0 || t == "听说考试" || lines.Contains(t)) continue;
                lines.Add(t);
            }
            return string.Join("\n", lines.ToArray());
        }

        public static Paper Load(string dir, int pid)
        {
            var d = Parse(Path.Combine(dir, "data.json"));
            var p = new Paper();
            p.Id = d.ContainsKey("id") ? Convert.ToInt32(d["id"]) : pid;
            p.Name = S(d, "name");
            p.Total = S(d, "totalScore");
            p.Dir = dir;
            int n = 0;
            foreach (object po in A(d, "partList"))
            {
                var pd = po as Dictionary<string, object>;
                if (pd == null) continue;
                var part = new Part();
                part.Name = S(pd, "name");
                var seen = new HashSet<string>();
                foreach (object ao in A(pd, "actionList"))
                {
                    var ad = ao as Dictionary<string, object>;
                    if (ad == null) continue;
                    object vo;
                    if (ad.TryGetValue("view", out vo) && vo is Dictionary<string, object>)
                    {
                        var vd = (Dictionary<string, object>)vo;
                        string fn = S(vd, "fileName");
                        if (fn.Length > 0)
                        {
                            string fp = Path.Combine(dir, fn);
                            if (File.Exists(fp))
                            {
                                string t = StripTags(File.ReadAllText(fp, Encoding.UTF8));
                                string sig = t.Length > 60 ? t.Substring(0, 60) : t;
                                if (t.Length > 0 && !seen.Contains(sig))
                                {
                                    seen.Add(sig);
                                    if (part.Context.Count < 2) part.Context.Add(t);
                                }
                            }
                        }
                    }
                }
                foreach (object ao in A(pd, "actionList"))
                {
                    var ad = ao as Dictionary<string, object>;
                    if (ad == null) continue;
                    foreach (object qo in A(ad, "questionList"))
                    {
                        var qd = qo as Dictionary<string, object>;
                        if (qd == null) continue;
                        n++;
                        var q = new Question();
                        q.No = n;
                        q.Name = CleanName(S(qd, "name"));
                        q.Score = D(qd, "score");
                        q.Text = S(qd, "text");
                        q.Answer = S(qd, "answer");
                        q.Keypoints = S(qd, "keypoints");
                        string ec = S(qd, "evalContent");
                        var vs = new List<string>();
                        foreach (string x in ec.Split('|'))
                        {
                            string t = x.Trim();
                            if (t.Length > 0 && !vs.Contains(t)) vs.Add(t);
                        }
                        vs.Sort(delegate (string a, string b) { return b.Length.CompareTo(a.Length); });
                        q.Variants = vs;
                        part.Questions.Add(q);
                        part.Score += q.Score;
                    }
                }
                p.Parts.Add(part);
            }
            return p;
        }

        public static List<KeyValuePair<int, string[]>> Scan()
        {
            var found = new Dictionary<int, string[]>();
            foreach (string baseDir in Paths.SearchDirs())
            {
                if (!Directory.Exists(baseDir)) continue;
                string[] files;
                try { files = Directory.GetFiles(baseDir, "data.json", SearchOption.AllDirectories); }
                catch { continue; }
                foreach (string f in files)
                {
                    try
                    {
                        var d = Parse(f);
                        int pid;
                        object ido;
                        if (!d.TryGetValue("id", out ido) || ido == null) continue;
                        pid = Convert.ToInt32(ido);
                        string name = S(d, "name");
                        string total = S(d, "totalScore");
                        found[pid] = new string[] { f, name, total };
                    }
                    catch { }
                }
            }
            return found.OrderBy(k => k.Key)
                        .Select(k => new KeyValuePair<int, string[]>(k.Key, k.Value)).ToList();
        }
    }

    // ---------- ZipCrypto + deflate ----------
    static class ZipReader
    {
        static readonly uint[] CrcTable = BuildTable();
        static uint[] BuildTable()
        {
            var t = new uint[256];
            for (uint i = 0; i < 256; i++)
            {
                uint c = i;
                for (int k = 0; k < 8; k++) c = ((c & 1) != 0) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
                t[i] = c;
            }
            return t;
        }
        static uint Crc(uint crc, byte b) { return (crc >> 8) ^ CrcTable[(crc ^ b) & 0xFF]; }

        class Keys
        {
            uint k0 = 0x12345678, k1 = 0x23456789, k2 = 0x34567890;
            public void Update(byte c)
            {
                k0 = Crc(k0, c);
                k1 = (k1 + (k0 & 0xFF)) * 134775813u + 1;
                k2 = Crc(k2, (byte)(k1 >> 24));
            }
            public byte Stream()
            {
                uint t = (k2 | 2) & 0xFFFF;
                return (byte)((t * (t ^ 1)) >> 8);
            }
        }

        static ushort U16(byte[] b, int o) { return (ushort)(b[o] | (b[o + 1] << 8)); }
        static uint U32(byte[] b, int o) { return (uint)(b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)); }

        public static void Extract(string zipPath, string outDir, string password)
        {
            byte[] data = File.ReadAllBytes(zipPath);
            int eocd = -1;
            for (int i = data.Length - 22; i >= Math.Max(0, data.Length - 65557); i--)
            {
                if (data[i] == 0x50 && data[i + 1] == 0x4B && data[i + 2] == 0x05 && data[i + 3] == 0x06) { eocd = i; break; }
            }
            if (eocd < 0) throw new Exception("不是有效的 zip 文件");
            int count = U16(data, eocd + 10);
            uint cdOff = U32(data, eocd + 16);
            int p = (int)cdOff;
            byte[] pw = Encoding.UTF8.GetBytes(password);
            Directory.CreateDirectory(outDir);
            for (int i = 0; i < count; i++)
            {
                if (U32(data, p) != 0x02014b50) break;
                ushort flags = U16(data, p + 8);
                ushort method = U16(data, p + 10);
                uint crc = U32(data, p + 16);
                uint compSize = U32(data, p + 20);
                int nameLen = U16(data, p + 28);
                int extraLen = U16(data, p + 30);
                int commentLen = U16(data, p + 32);
                uint localOff = U32(data, p + 42);
                string name = Encoding.UTF8.GetString(data, p + 46, nameLen);
                p += 46 + nameLen + extraLen + commentLen;

                if (name.EndsWith("/")) continue;
                string rel = name;
                int slash = rel.IndexOf('/');
                if (slash >= 0) rel = rel.Substring(slash + 1);
                if (rel.Length == 0) continue;

                int ln = U16(data, (int)localOff + 26);
                int le = U16(data, (int)localOff + 28);
                int start = (int)localOff + 30 + ln + le;
                byte[] comp = new byte[compSize];
                Buffer.BlockCopy(data, start, comp, 0, (int)compSize);

                byte[] plain;
                if ((flags & 1) != 0)
                {
                    var ks = new Keys();
                    foreach (byte c in pw) ks.Update(c);
                    for (int k = 0; k < 12 && k < comp.Length; k++)
                    {
                        comp[k] ^= ks.Stream();
                        ks.Update(comp[k]);
                    }
                    byte check = (flags & 8) != 0 ? (byte)(U16(data, (int)localOff + 10) >> 8) : (byte)(crc >> 24);
                    if (comp[11] != check) throw new Exception("zip 口令错误");
                    for (int k = 12; k < comp.Length; k++)
                    {
                        comp[k] ^= ks.Stream();
                        ks.Update(comp[k]);
                    }
                    plain = new byte[comp.Length - 12];
                    Buffer.BlockCopy(comp, 12, plain, 0, plain.Length);
                }
                else plain = comp;

                byte[] content;
                if (method == 0) content = plain;
                else
                {
                    using (var ms = new MemoryStream(plain))
                    using (var ds = new DeflateStream(ms, CompressionMode.Decompress))
                    using (var outMs = new MemoryStream())
                    {
                        ds.CopyTo(outMs);
                        content = outMs.ToArray();
                    }
                }
                string fp = Path.Combine(outDir, rel.Replace('/', '\\'));
                Directory.CreateDirectory(Path.GetDirectoryName(fp));
                File.WriteAllBytes(fp, content);
            }
        }
    }

    // ---------- CDP over websocket ----------
    static class Cdp
    {
        static string PageWs()
        {
            var wc = new WebClient();
            wc.Proxy = null;
            string list = wc.DownloadString("http://127.0.0.1:9222/json/list");
            var ser = new JavaScriptSerializer();
            var arr = (object[])ser.DeserializeObject(list);
            foreach (object o in arr)
            {
                var d = (Dictionary<string, object>)o;
                if (d.ContainsKey("type") && Convert.ToString(d["type"]) == "page")
                    return Convert.ToString(d["webSocketDebuggerUrl"]);
            }
            throw new Exception("未找到客户端页面");
        }

        public static bool Alive()
        {
            try
            {
                var wc = new WebClient();
                wc.Proxy = null;
                wc.DownloadString("http://127.0.0.1:9222/json/version");
                return true;
            }
            catch { return false; }
        }

        public static string Eval(string expr)
        {
            string url = PageWs();
            using (var ws = new ClientWebSocket())
            {
                ws.Options.Proxy = null;
                ws.ConnectAsync(new Uri(url), CancellationToken.None).Wait(15000);
                string req = "{\"id\":1,\"method\":\"Runtime.evaluate\",\"params\":{\"expression\":" +
                             Quote(expr) + ",\"returnByValue\":true}}";
                byte[] buf = Encoding.UTF8.GetBytes(req);
                ws.SendAsync(new ArraySegment<byte>(buf), WebSocketMessageType.Text, true, CancellationToken.None).Wait(15000);
                var sb = new StringBuilder();
                var data = new byte[65536];
                while (true)
                {
                    var r = ws.ReceiveAsync(new ArraySegment<byte>(data), CancellationToken.None).Result;
                    sb.Append(Encoding.UTF8.GetString(data, 0, r.Count));
                    if (r.EndOfMessage) break;
                    if (sb.Length > 8 * 1024 * 1024) break;
                }
                var ser = new JavaScriptSerializer();
                var msg = (Dictionary<string, object>)ser.DeserializeObject(sb.ToString());
                var res = msg.ContainsKey("result") ? (Dictionary<string, object>)msg["result"] : null;
                if (res != null && res.ContainsKey("exceptionDetails"))
                {
                    var ex = (Dictionary<string, object>)res["exceptionDetails"];
                    throw new Exception("JS 错误: " + Convert.ToString(ex["text"]));
                }
                if (res != null && res.ContainsKey("result"))
                {
                    var inner = (Dictionary<string, object>)res["result"];
                    if (inner.ContainsKey("value")) return Convert.ToString(inner["value"], CultureInfo.InvariantCulture);
                }
                return null;
            }
        }

        public static string Quote(string s)
        {
            return new JavaScriptSerializer().Serialize(s);
        }
    }

    static class Fetcher
    {
        public static void EnsureClient(Action<string> log)
        {
            if (Cdp.Alive()) return;
            string exe = Paths.ClientExe;
            if (exe == null) throw new Exception("未找到口语易客户端 kyyclient.exe");
            log("正在启动口语易客户端…");
            Process.Start(new ProcessStartInfo(exe, "--remote-debugging-port=9222 --disable-gpu") { UseShellExecute = true });
            for (int i = 0; i < 120; i++)
            {
                Thread.Sleep(500);
                if (Cdp.Alive()) return;
            }
            throw new Exception("客户端调试端口 9222 未就绪");
        }

        public static void EnsureLogin(Action<string> log)
        {
            for (int i = 0; i < 60; i++)
            {
                string st = null;
                try { st = Cdp.Eval("JSON.stringify({h:(typeof g_hasLogin!=='undefined'?g_hasLogin:null),u:location.href})"); }
                catch { }
                if (!string.IsNullOrEmpty(st))
                {
                    var ser = new JavaScriptSerializer();
                    var d = (Dictionary<string, object>)ser.DeserializeObject(st);
                    bool has = d.ContainsKey("h") && d["h"] is bool && (bool)d["h"];
                    string u = d.ContainsKey("u") ? Convert.ToString(d["u"]) : "";
                    if (has || u.Contains("index_afterlogin")) return;
                }
                try
                {
                    Cdp.Eval("(function(){var b=document.querySelectorAll('input[name=type]');if(b&&b.length){b[0].click();return 'clicked';}return 'noBtn';})()");
                }
                catch { }
                Thread.Sleep(1000);
            }
            throw new Exception("自动登录失败, 请先手动打开口语易并登录");
        }

        public static string GetKey(int pid, Action<string> log)
        {
            string js = "(function(){window.__k=null;window.__ke=null;" +
                "kyyQuery({request:'listenspeak.getPaperDetail',persistent:true," +
                "parameters:'{\"unitId\":" + pid + ",\"unitType\":22,\"comeFrom\":4}'," +
                "onSuccess:function(r){window.__k=r;},onFailure:function(c,m){window.__ke=c+' '+m;}});" +
                "return 'fired';})()";
            for (int attempt = 0; attempt < 3; attempt++)
            {
                Cdp.Eval(js);
                string v = null;
                for (int i = 0; i < 40; i++)
                {
                    Thread.Sleep(250);
                    v = Cdp.Eval("window.__k ? window.__k : (window.__ke ? 'ERR:'+window.__ke : '')");
                    if (!string.IsNullOrEmpty(v)) break;
                }
                if (!string.IsNullOrEmpty(v) && !v.StartsWith("ERR:"))
                {
                    var d = (Dictionary<string, object>)new JavaScriptSerializer().DeserializeObject(v);
                    return Convert.ToString(d["encryptKey"]);
                }
                if (v != null && v.IndexOf("cancel", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    Thread.Sleep(1000);
                    continue;
                }
                throw new Exception("取口令失败: " + (v ?? "无响应"));
            }
            throw new Exception("取口令失败: 请求被取消");
        }

        public static string Fetch(int pid, Action<string> log)
        {
            EnsureClient(log);
            EnsureLogin(log);
            log("正在向客户端索取口令…");
            string key = GetKey(pid, log);
            log("口令 " + key + "，正在下载试卷…");
            string zip = Path.Combine(Paths.Pkg, pid + ".zip");
            if (!File.Exists(zip) || new FileInfo(zip).Length < 1000)
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; // Tls12
                ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                var wc = new WebClient();
                wc.Proxy = null;
                wc.Headers.Add("User-Agent", "Mozilla/5.0");
                wc.DownloadFile("https://std.kouyuyi.com/res/listenSpeakExam/zipPackage/" + pid + ".zip", zip);
            }
            log("正在解包…");
            string dir = Path.Combine(Paths.Pkg, pid.ToString());
            ZipReader.Extract(zip, dir, key);
            return dir;
        }
    }

    // ---------- exports ----------
    static class Exporter
    {
        static string Fmt(double d)
        {
            return d == Math.Floor(d) ? ((int)d).ToString() : d.ToString("0.#", CultureInfo.InvariantCulture);
        }

        public static string Md(Paper p)
        {
            var sb = new StringBuilder();
            sb.AppendLine("# 口语易 听说练习 " + p.Id + "：" + p.Name);
            sb.AppendLine();
            sb.AppendLine("- 满分 " + p.Total + " 分");
            sb.AppendLine();
            sb.AppendLine("## 答案速查");
            sb.AppendLine();
            sb.AppendLine("| 题号 | 参考答案（首选） |");
            sb.AppendLine("|---|---|");
            foreach (Question q in p.AllQuestions())
            {
                string refa = q.Variants.Count > 0 ? q.Variants[0] : q.Answer;
                sb.AppendLine("| " + q.Head + " | " + refa.Replace("|", "/") + " |");
            }
            foreach (Part part in p.Parts)
            {
                sb.AppendLine();
                sb.AppendLine("## " + part.Name + "（" + Fmt(part.Score) + " 分）");
                foreach (string c in part.Context)
                {
                    sb.AppendLine();
                    foreach (string line in c.Split('\n')) sb.AppendLine("> " + line);
                }
                foreach (Question q in part.Questions)
                {
                    sb.AppendLine();
                    sb.AppendLine("### " + q.Head + "（" + Fmt(q.Score) + " 分）");
                    if (q.Text.Length > 0) { sb.AppendLine(); sb.AppendLine(q.Text); }
                    if (q.Answer.Length > 0) { sb.AppendLine(); sb.AppendLine("**答案：" + q.Answer + "**"); }
                    if (q.Variants.Count > 0)
                    {
                        sb.AppendLine();
                        sb.AppendLine("**参考答案（" + q.Variants.Count + " 种表述，均可得分）：**");
                        foreach (string v in q.Variants) sb.AppendLine("- " + v);
                    }
                    if (q.Keypoints.Length > 0 && q.Keypoints != "[]" && q.Keypoints != "{}")
                    {
                        sb.AppendLine();
                        sb.AppendLine("要点：" + q.Keypoints);
                    }
                }
            }
            return sb.ToString();
        }

        public static string Html(Paper p)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">");
            sb.AppendLine("<title>" + H(p.Name) + "</title>");
            sb.AppendLine("<style>body{font-family:'Microsoft YaHei',sans-serif;max-width:900px;margin:24px auto;line-height:1.7;color:#222}" +
                          "h1{color:#1f3b57}h2{color:#1f3b57;border-bottom:1px solid #ddd;padding-bottom:4px;margin-top:28px}" +
                          "h3{margin:18px 0 6px}.ctx{color:#666;font-size:13px;background:#f7f7f7;padding:8px 12px;border-left:3px solid #ccc}" +
                          ".ans{color:#b00000;font-weight:bold}.v{margin:2px 0 2px 18px}.key{color:#2e74b5;font-size:13px}" +
                          "table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:4px 8px;font-size:13px}</style></head><body>");
            sb.AppendLine("<h1>口语易 听说练习 " + p.Id + "：" + H(p.Name) + "</h1>");
            sb.AppendLine("<p>满分 " + H(p.Total) + " 分</p>");
            sb.AppendLine("<h2>答案速查</h2><table><tr><th>题号</th><th>参考答案（首选）</th></tr>");
            foreach (Question q in p.AllQuestions())
            {
                string refa = q.Variants.Count > 0 ? q.Variants[0] : q.Answer;
                sb.AppendLine("<tr><td>" + H(q.Head) + "</td><td>" + H(refa) + "</td></tr>");
            }
            sb.AppendLine("</table>");
            foreach (Part part in p.Parts)
            {
                sb.AppendLine("<h2>" + H(part.Name) + "（" + Fmt(part.Score) + " 分）</h2>");
                foreach (string c in part.Context)
                    sb.AppendLine("<div class=\"ctx\">" + H(c).Replace("\n", "<br>") + "</div>");
                foreach (Question q in part.Questions)
                {
                    sb.AppendLine("<h3>" + H(q.Head) + "（" + Fmt(q.Score) + " 分）</h3>");
                    if (q.Answer.Length > 0) sb.AppendLine("<div class=\"ans\">答案：" + H(q.Answer) + "</div>");
                    for (int i = 0; i < q.Variants.Count; i++)
                        sb.AppendLine("<div class=\"v\">" + (i == 0 ? "<b class=\"ans\">" : "") + H(q.Variants[i]) + (i == 0 ? "</b>" : "") + "</div>");
                    if (q.Keypoints.Length > 0 && q.Keypoints != "[]" && q.Keypoints != "{}")
                        sb.AppendLine("<div class=\"key\">得分要点：" + H(q.Keypoints) + "</div>");
                }
            }
            sb.AppendLine("</body></html>");
            return sb.ToString();
        }

        public static void Docx(Paper p, string path)
        {
            var body = new StringBuilder();
            body.Append(Para(p.Name, 36, true, "1F3B57"));
            body.Append(Para("满分 " + p.Total + " 分 · 提取自口语易客户端题库包", 18, false, "666666"));
            foreach (Part part in p.Parts)
            {
                body.Append(Para(part.Name + "（" + Fmt(part.Score) + " 分）", 28, true, "1F3B57"));
                foreach (string c in part.Context)
                    foreach (string line in c.Split('\n'))
                        body.Append(Para(line, 17, false, "666666"));
                foreach (Question q in part.Questions)
                {
                    body.Append(Para(q.Head + "（" + Fmt(q.Score) + " 分）", 22, true, "333333"));
                    if (q.Text.Length > 0) body.Append(Para(q.Text, 20, false, "222222"));
                    if (q.Answer.Length > 0) body.Append(Para("答案：" + q.Answer, 22, true, "B00000"));
                    for (int i = 0; i < q.Variants.Count; i++)
                        body.Append(Para((i == 0 ? "★ " : "· ") + q.Variants[i], 20, i == 0, i == 0 ? "B00000" : "222222"));
                    if (q.Keypoints.Length > 0 && q.Keypoints != "[]" && q.Keypoints != "{}")
                        body.Append(Para("得分要点：" + q.Keypoints, 17, false, "2E74B5"));
                }
            }
            string doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>" +
                body + "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\"/></w:sectPr>" +
                "</w:body></w:document>";
            string types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                "</Types>";
            string rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                "</Relationships>";
            if (File.Exists(path)) File.Delete(path);
            using (var fs = new FileStream(path, FileMode.Create))
            using (var za = new ZipArchive(fs, ZipArchiveMode.Create))
            {
                WriteEntry(za, "[Content_Types].xml", types);
                WriteEntry(za, "_rels/.rels", rels);
                WriteEntry(za, "word/document.xml", doc);
            }
        }

        static string Para(string text, int halfPoints, bool bold, string color)
        {
            string rpr = "<w:rPr><w:rFonts w:ascii=\"微软雅黑\" w:eastAsia=\"微软雅黑\" w:hAnsi=\"微软雅黑\"/>" +
                         (bold ? "<w:b/>" : "") + "<w:color w:val=\"" + color + "\"/><w:sz w:val=\"" + halfPoints + "\"/></w:rPr>";
            return "<w:p><w:pPr><w:spacing w:after=\"80\"/></w:pPr><w:r>" + rpr +
                   "<w:t xml:space=\"preserve\">" + H(text) + "</w:t></w:r></w:p>";
        }

        static void WriteEntry(ZipArchive za, string name, string content)
        {
            var e = za.CreateEntry(name, CompressionLevel.Optimal);
            using (var s = e.Open())
            {
                byte[] b = new UTF8Encoding(false).GetBytes(content);
                s.Write(b, 0, b.Length);
            }
        }

        static string H(string s)
        {
            if (s == null) return "";
            return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
        }
    }

    // ---------- UI ----------
    class MainForm : Form
    {
        ListBox list;
        RichTextBox text;
        TextBox idBox;
        CheckBox quick;
        Label title;
        Label status;
        Button fetchBtn, exportBtn, exportMdBtn;
        ComboBox voiceBox;
        TrackBar rateBar;
        Label rateLbl;
        Button speakBtn, stopBtn, saveWavBtn, batchBtn, dlBtn;
        ComboBox qBox, outBox;
        Button playQBtn;
        List<Question> qItems = new List<Question>();
        List<int[]> qSpan = new List<int[]>();
        List<string> qText = new List<string>();
        List<KeyValuePair<int, string[]>> items = new List<KeyValuePair<int, string[]>>();
        Paper current;
        public int want = -1;

        public MainForm()
        {
            Text = "口语易 · 听说练习答案查看器";
            Width = 1200; Height = 800;
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Microsoft YaHei UI", 9f);
            MinimumSize = new Size(900, 600);
            Paths.Ensure();
            BuildUi();
            InitVoices();
            InitDevices();
            RefreshList();
        }

        void BuildUi()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 142, Padding = new Padding(10, 9, 10, 6) };
            Controls.Add(top);

            var l1 = new Label { Text = "试卷编号:", AutoSize = true, Location = new Point(10, 15) };
            top.Controls.Add(l1);
            idBox = new TextBox { Location = new Point(76, 12), Width = 90 };
            top.Controls.Add(idBox);

            fetchBtn = new Button { Text = "获取/更新该试卷", Location = new Point(174, 10), Width = 130, Height = 26 };
            fetchBtn.Click += delegate { FetchPaper(); };
            top.Controls.Add(fetchBtn);

            var refreshBtn = new Button { Text = "刷新列表", Location = new Point(312, 10), Width = 84, Height = 26 };
            refreshBtn.Click += delegate { RefreshList(); };
            top.Controls.Add(refreshBtn);

            quick = new CheckBox { Text = "只看答案速查", AutoSize = true, Location = new Point(760, 14) };
            quick.CheckedChanged += delegate { Render(); };
            top.Controls.Add(quick);

            exportBtn = new Button { Text = "导出 Word", Width = 96, Height = 26, Anchor = AnchorStyles.Top | AnchorStyles.Right };
            exportBtn.Location = new Point(top.Width - 106, 10);
            exportBtn.Click += delegate { Export("docx"); };
            top.Controls.Add(exportBtn);

            exportMdBtn = new Button { Text = "导出 HTML", Width = 96, Height = 26, Anchor = AnchorStyles.Top | AnchorStyles.Right };
            exportMdBtn.Location = new Point(top.Width - 208, 10);
            exportMdBtn.Click += delegate { Export("html"); };
            top.Controls.Add(exportMdBtn);

            // ---- 第二行: 本地语音合成 ----
            var sep = new Label { BorderStyle = BorderStyle.Fixed3D, Height = 2, Width = top.Width - 20, Location = new Point(10, 45), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
            top.Controls.Add(sep);
            top.Controls.Add(new Label { Text = "语音:", AutoSize = true, Location = new Point(10, 60) });

            voiceBox = new ComboBox { Location = new Point(48, 56), Width = 330, DropDownStyle = ComboBoxStyle.DropDownList };
            top.Controls.Add(voiceBox);

            top.Controls.Add(new Label { Text = "语速", AutoSize = true, Location = new Point(390, 60) });
            rateBar = new TrackBar
            {
                Location = new Point(424, 52), Width = 140,
                Minimum = 60, Maximum = 160, Value = 100, TickStyle = TickStyle.None,
                SmallChange = 5, LargeChange = 10, Height = 32
            };
            top.Controls.Add(rateBar);
            rateLbl = new Label { Text = "100%", AutoSize = true, Location = new Point(566, 60) };
            top.Controls.Add(rateLbl);
            rateBar.ValueChanged += delegate { rateLbl.Text = rateBar.Value + "%"; };

            speakBtn = new Button { Text = "▶ 朗读答案", Location = new Point(612, 52), Width = 104, Height = 28 };
            speakBtn.Click += delegate { SpeakCurrent(); };
            top.Controls.Add(speakBtn);

            stopBtn = new Button { Text = "■ 停止", Location = new Point(722, 52), Width = 70, Height = 28 };
            stopBtn.Click += delegate { AudioOut.Stop(); SetStatus("已停止播放"); };
            top.Controls.Add(stopBtn);

            saveWavBtn = new Button { Text = "保存音频", Location = new Point(798, 52), Width = 84, Height = 28 };
            saveWavBtn.Click += delegate { SaveAudio(); };
            top.Controls.Add(saveWavBtn);

            batchBtn = new Button { Text = "批量生成答案语音", Location = new Point(888, 52), Width = 140, Height = 28 };
            batchBtn.Click += delegate { BatchAudio(); };
            top.Controls.Add(batchBtn);

            dlBtn = new Button { Text = "下载/修复语音模型", Width = 150, Height = 28, Anchor = AnchorStyles.Top | AnchorStyles.Right };
            dlBtn.Location = new Point(top.Width - 160, 52);
            dlBtn.Click += delegate { DownloadTts(); };
            top.Controls.Add(dlBtn);

            // ---- 第三行: 单题播放 + 输出设备 ----
            top.Controls.Add(new Label { Text = "题目:", AutoSize = true, Location = new Point(10, 106) });
            qBox = new ComboBox { Location = new Point(48, 102), Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            qBox.DoubleClick += delegate { PlaySelectedQuestion(); };
            top.Controls.Add(qBox);
            playQBtn = new Button { Text = "▶ 播放该题", Location = new Point(356, 100), Width = 100, Height = 26 };
            playQBtn.Click += delegate { PlaySelectedQuestion(); };
            top.Controls.Add(playQBtn);

            top.Controls.Add(new Label { Text = "输出设备:", AutoSize = true, Location = new Point(464, 106) });
            outBox = new ComboBox { Location = new Point(530, 102), Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            top.Controls.Add(outBox);

            var openDirBtn = new Button { Text = "打开语音文件夹", Location = new Point(838, 100), Width = 120, Height = 26 };
            openDirBtn.Click += delegate { OpenAudioFolder(); };
            top.Controls.Add(openDirBtn);

            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 26 };
            status = new Label { Dock = DockStyle.Fill, Text = "就绪", ForeColor = Color.DimGray, Padding = new Padding(10, 5, 0, 0) };
            bottom.Controls.Add(status);
            Controls.Add(bottom);

            var split = new SplitContainer { Dock = DockStyle.Fill, SplitterDistance = 400, FixedPanel = FixedPanel.Panel1 };
            Controls.Add(split);
            split.BringToFront();

            var leftPanel = new Panel { Dock = DockStyle.Fill };
            leftPanel.Controls.Add(new Label { Text = "本机已有的试卷", Dock = DockStyle.Top, Height = 24, Padding = new Padding(4, 4, 0, 0), ForeColor = Color.DimGray });
            list = new ListBox { Dock = DockStyle.Fill, IntegralHeight = false, BorderStyle = BorderStyle.FixedSingle, HorizontalScrollbar = true };
            list.SelectedIndexChanged += delegate { OnSelect(); };
            leftPanel.Controls.Add(list);
            list.BringToFront();
            split.Panel1.Controls.Add(leftPanel);

            title = new Label { Dock = DockStyle.Top, Height = 34, Font = new Font("Microsoft YaHei UI", 12f, FontStyle.Bold), ForeColor = Color.FromArgb(31, 59, 87), Padding = new Padding(8, 6, 0, 0) };
            split.Panel2.Controls.Add(title);
            text = new RichTextBox { Dock = DockStyle.Fill, ReadOnly = true, BorderStyle = BorderStyle.None, BackColor = Color.FromArgb(253, 253, 250), Font = new Font("Microsoft YaHei UI", 9.5f), WordWrap = true };
            split.Panel2.Controls.Add(text);
            text.BringToFront();
            text.Padding = new Padding(10);

            AudioOut.Finished += delegate
            {
                try
                {
                    BeginInvoke((Action)delegate
                    {
                        if (status.Text.StartsWith("正在播放")) SetStatus("播放完成");
                    });
                }
                catch { }
            };
        }

        void RefreshList()
        {
            try { items = PaperStore.Scan(); }
            catch { items = new List<KeyValuePair<int, string[]>>(); }
            list.BeginUpdate();
            list.Items.Clear();
            foreach (var it in items) list.Items.Add("  " + it.Key + "   " + it.Value[1]);
            list.EndUpdate();
            if (items.Count > 0)
            {
                int idx = 0;
                if (want > 0)
                {
                    for (int i = 0; i < items.Count; i++) if (items[i].Key == want) { idx = i; break; }
                }
                list.SelectedIndex = idx;
            }
            else
            {
                title.Text = "还没有本机试卷：在上面输入编号点“获取/更新该试卷”";
            }
        }

        public void RefreshListPublic() { RefreshList(); }

        void OnSelect()        {
            if (list.SelectedIndex < 0 || list.SelectedIndex >= items.Count) return;
            var it = items[list.SelectedIndex];
            try
            {
                current = PaperStore.Load(Path.GetDirectoryName(it.Value[0]), it.Key);
                title.Text = current.Id + "　" + current.Name + "　（满分 " + current.Total + " 分）";
                Render();
            }
            catch (Exception e)
            {
                current = null;
                title.Text = "读取失败: " + e.Message;
                text.Clear();
            }
        }

        void Add(string s, Font f, Color c)
        {
            text.SelectionStart = text.TextLength;
            text.SelectionLength = 0;
            text.SelectionFont = f;
            text.SelectionColor = c;
            text.AppendText(s);
        }

        static string Fmt(double d) { return d == Math.Floor(d) ? ((int)d).ToString() : d.ToString("0.#"); }

        void Render()
        {
            text.Clear();
            qSpan.Clear();
            qText.Clear();
            if (current == null) return;
            var fH2 = new Font("Microsoft YaHei UI", 12f, FontStyle.Bold);
            var fH3 = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold);
            var fBody = new Font("Microsoft YaHei UI", 9.5f);
            var fCtx = new Font("Microsoft YaHei UI", 8.5f);
            var fAns = new Font("Microsoft YaHei UI", 10.5f, FontStyle.Bold);
            var fKey = new Font("Microsoft YaHei UI", 8.5f);
            Color blue = Color.FromArgb(31, 59, 87), red = Color.FromArgb(176, 0, 0), gray = Color.FromArgb(100, 100, 100);

            if (quick.Checked)
            {
                foreach (Part part in current.Parts)
                    foreach (Question q in part.Questions)
                    {
                        int s0 = text.TextLength;
                        Add(q.Head + "： ", fH3, Color.FromArgb(51, 51, 51));
                        Add((q.Variants.Count > 0 ? q.Variants[0] : q.Answer) + "\n", fAns, red);
                        qSpan.Add(new[] { s0, text.TextLength });
                        qText.Add(q.Variants.Count > 0 ? q.Variants[0] : q.Answer);
                    }
                text.SelectionStart = 0;
                text.SelectionLength = 0;
                text.ScrollToCaret();
                FillQuestionList();
                return;
            }

            foreach (Part part in current.Parts)
            {
                Add(part.Name + "（" + Fmt(part.Score) + " 分）\n", fH2, blue);
                foreach (string c in part.Context)
                    Add(c + "\n", fCtx, gray);
                foreach (Question q in part.Questions)
                {
                    int s0 = text.TextLength;
                    Add(q.Head + "　（" + Fmt(q.Score) + " 分）\n", fH3, Color.FromArgb(51, 51, 51));
                    if (q.Answer.Length > 0) Add("答案：" + q.Answer + "\n", fAns, red);
                    for (int i = 0; i < q.Variants.Count; i++)
                        Add((i == 0 ? "★ " : "· ") + q.Variants[i] + "\n", i == 0 ? fAns : fBody, i == 0 ? red : Color.FromArgb(34, 34, 34));
                    if (q.Keypoints.Length > 0 && q.Keypoints != "[]" && q.Keypoints != "{}")
                        Add("得分要点：" + q.Keypoints + "\n", fKey, Color.FromArgb(46, 116, 181));
                    qSpan.Add(new[] { s0, text.TextLength });
                    qText.Add(q.Variants.Count > 0 ? q.Variants[0] : q.Answer);
                }
                Add("\n", fBody, Color.Black);
            }
            text.SelectionStart = 0;
            text.SelectionLength = 0;
            text.ScrollToCaret();
            FillQuestionList();
        }

        void SetStatus(string s) { status.Text = s; }

        void FetchPaper()
        {
            int pid;
            if (!int.TryParse(idBox.Text.Trim(), out pid))
            {
                MessageBox.Show(this, "请输入数字试卷编号，例如 11895", "提示");
                return;
            }
            fetchBtn.Enabled = false;
            SetStatus("正在获取 " + pid + " …");
            var t = new Thread(delegate ()
            {
                try
                {
                    string dir = Fetcher.Fetch(pid, delegate (string m) { BeginInvoke((Action)delegate { SetStatus(m); }); });
                    BeginInvoke((Action)delegate
                    {
                        want = pid;
                        RefreshList();
                        SetStatus("已完成: " + dir);
                        fetchBtn.Enabled = true;
                    });
                }
                catch (Exception e)
                {
                    string msg = e.Message;
                    if (e.InnerException != null) msg += " / " + e.InnerException.Message;
                    BeginInvoke((Action)delegate
                    {
                        SetStatus("失败: " + msg);
                        fetchBtn.Enabled = true;
                        MessageBox.Show(this, msg, "获取失败");
                    });
                }
            });
            t.IsBackground = true;
            t.Start();
        }

        // ---------- 本地语音合成 ----------
        void InitVoices()
        {
            try
            {
                voiceBox.Items.Clear();
                foreach (VoiceInfo v in Tts.Voices()) voiceBox.Items.Add(v);
                voiceBox.DisplayMember = "Name";
                int idx = 0;
                for (int i = 0; i < voiceBox.Items.Count; i++)
                    if (((VoiceInfo)voiceBox.Items[i]).Id == "auto") { idx = i; break; }
                if (voiceBox.Items.Count > 0) voiceBox.SelectedIndex = idx;
            }
            catch { }
            UpdateTtsUi();
        }

        void InitDevices()
        {
            try
            {
                outBox.Items.Clear();
                foreach (AudioOut.Device d in AudioOut.Devices()) outBox.Items.Add(d);
                outBox.DisplayMember = "Name";
                int pick = 0;
                int best = 99;
                for (int i = 0; i < outBox.Items.Count; i++)
                {
                    string n = ((AudioOut.Device)outBox.Items[i]).Name.ToLowerInvariant();
                    int score = 99;
                    if (n.Contains("cable input")) score = 0;
                    else if (n.Contains("cable")) score = 1;
                    else if (n.Contains("voicemeeter")) score = 2;
                    else if (n.Contains("virtual") || n.Contains("虚拟")) score = 3;
                    else if (n.Contains("stereo mix") || n.Contains("立体声")) score = 4;
                    if (score < best) { best = score; pick = i; }
                }
                if (outBox.Items.Count > 0) outBox.SelectedIndex = pick;
            }
            catch { }
        }

        void UpdateTtsUi()        {
            string s;
            if (Tts.PiperReady && Tts.ModelReady("en_US-lessac-medium") && Tts.ModelReady("zh_CN-huayan-medium"))
                s = "本地神经语音已就绪（离线，CPU 推理）";
            else if (Tts.PiperReady)
                s = "本地引擎已安装，模型不全，点“下载/修复语音模型”补齐";
            else
                s = "本地语音模型未安装：点“下载/修复语音模型”（约 150MB，一次即可）";
            SetStatus(s);
        }

        string SelectedOrCurrentText()
        {
            string t = text.SelectedText;
            if (!string.IsNullOrEmpty(t) && t.Trim().Length > 0) return t.Trim();
            int pos = text.SelectionStart;
            for (int i = 0; i < qSpan.Count; i++)
                if (pos >= qSpan[i][0] && pos <= qSpan[i][1]) return qText[i];
            for (int i = 0; i < qSpan.Count; i++)
                if (qSpan[i][0] > pos) return qText[i];
            return qText.Count > 0 ? qText[0] : "";
        }

        string CurrentVoiceId()
        {
            var v = voiceBox.SelectedItem as VoiceInfo;
            return v != null ? v.Id : "auto";
        }

        double CurrentRate() { return rateBar.Value / 100.0; }

        static string SafeName(string s)
        {
            foreach (char c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
            return s.Length > 60 ? s.Substring(0, 60) : s;
        }

        void FillQuestionList()
        {
            qItems.Clear();
            qBox.Items.Clear();
            if (current == null) return;
            int i = 0;
            foreach (Question q in current.AllQuestions())
            {
                i++;
                qItems.Add(q);
                qBox.Items.Add(string.Format("{0:00} {1}（{2}分）", i, q.Head, Fmt(q.Score)));
            }
            if (qBox.Items.Count > 0) qBox.SelectedIndex = 0;
        }

        void PlaySelectedQuestion()
        {
            if (qBox.SelectedIndex < 0 || qBox.SelectedIndex >= qItems.Count)
            {
                SetStatus("请先选择一道题");
                return;
            }
            Question q = qItems[qBox.SelectedIndex];
            string body = q.Variants.Count > 0 ? q.Variants[0] : q.Answer;
            if (string.IsNullOrEmpty(body)) { SetStatus("这道题没有可朗读的答案"); return; }
            PlayText(body, q.Head);
        }

        int SelectedDeviceId()
        {
            var d = outBox.SelectedItem as AudioOut.Device;
            return d != null ? d.Id : -1;
        }

        string PreviewPath()
        {
            string dir = Path.Combine(Tts.OutDir(current != null ? current.Id : 0), "_cache");
            Directory.CreateDirectory(dir);
            return Path.Combine(dir, "preview.wav");
        }

        void PlayText(string body, string label)
        {
            if (!Tts.PiperReady && !File.Exists(Tts.PiperExe))
            {
                if (MessageBox.Show(this, "还没有本地语音模型，现在下载吗？（约 150MB）", "本地语音",
                        MessageBoxButtons.YesNo) == DialogResult.Yes) DownloadTts();
                return;
            }
            try
            {
                SetStatus("正在本地合成：" + label);
                string wav = PreviewPath();
                Tts.Synthesize(body, CurrentVoiceId(), CurrentRate(), wav);
                AudioOut.Play(wav, SelectedDeviceId());
                string devName = outBox.SelectedItem != null ? outBox.SelectedItem.ToString() : "默认设备";
                SetStatus("正在播放【" + label + "】→ " + devName +
                          (string.IsNullOrEmpty(AudioOut.LastError) ? "" : "（" + AudioOut.LastError + "）"));
            }
            catch (Exception e)
            {
                SetStatus("语音合成失败：" + e.Message);
                MessageBox.Show(this, e.Message, "语音合成失败");
            }
        }

        void OpenAudioFolder()
        {
            try
            {
                string dir = current != null ? Tts.OutDir(current.Id) : Tts.OutRoot;
                Directory.CreateDirectory(dir);
                Process.Start("explorer.exe", "\"" + dir + "\"");
                SetStatus("语音目录：" + dir);
            }
            catch (Exception e) { MessageBox.Show(this, e.Message, "打开失败"); }
        }

        void SpeakCurrent()
        {
            string txt = SelectedOrCurrentText();
            if (string.IsNullOrEmpty(txt)) { SetStatus("没有可朗读的内容"); return; }
            PlayText(txt, "当前答案");
        }

        void SaveAudio()
        {
            string txt = SelectedOrCurrentText();
            if (string.IsNullOrEmpty(txt)) { SetStatus("没有可保存的内容"); return; }
            var dlg = new SaveFileDialog { Filter = "WAV 音频|*.wav", FileName = "answer.wav", InitialDirectory = Tts.OutDir(current != null ? current.Id : 0) };
            if (dlg.ShowDialog(this) != DialogResult.OK) return;
            try
            {
                Cursor = Cursors.WaitCursor;
                string tmp = PreviewPath();
                Tts.Synthesize(txt, CurrentVoiceId(), CurrentRate(), tmp);
                File.Copy(tmp, dlg.FileName, true);
                SetStatus("已保存: " + dlg.FileName);
                MessageBox.Show(this, "音频已保存到：\n" + dlg.FileName, "保存完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e) { MessageBox.Show(this, e.Message, "保存失败"); }
            finally { Cursor = Cursors.Default; }
        }

        void BatchAudio()
        {
            if (current == null) { MessageBox.Show(this, "请先选择一份试卷"); return; }
            if (!Tts.PiperReady)
            {
                if (MessageBox.Show(this, "还没有本地语音模型，现在下载吗？（约 150MB）", "本地语音",
                        MessageBoxButtons.YesNo) == DialogResult.Yes) DownloadTts();
                return;
            }
            string dir = Tts.OutDir(current.Id);   // 自动在 exe 目录下建 “答案语音\试卷号”
            var qs = new List<Question>(current.AllQuestions());
            var pf = new ProgressForm();
            pf.Text = "批量生成答案语音";
            pf.Show(this);
            pf.Set("准备生成…", 0);
            Application.DoEvents();

            var t = new Thread(delegate ()
            {
                int ok = 0, fail = 0, n = 1;
                foreach (Question q in qs)
                {
                    string body = q.Variants.Count > 0 ? q.Variants[0] : q.Answer;
                    if (!string.IsNullOrEmpty(body))
                    {
                        string name = string.Format("{0:00}_{1}.wav", n, SafeName(q.Head));
                        string path = Path.Combine(dir, name);
                        int cur = n;
                        try
                        {
                            BeginInvoke((Action)delegate
                            {
                                pf.Set(string.Format("正在生成 {0}/{1}：{2}", cur, qs.Count, q.Head),
                                       (int)((cur - 1) * 100.0 / Math.Max(1, qs.Count)));
                            });
                            Tts.Synthesize(body, "auto", CurrentRate(), path);
                            ok++;
                        }
                        catch { fail++; }
                    }
                    n++;
                }
                try
                {
                    BeginInvoke((Action)delegate
                    {
                        pf.Set("完成", 100);
                        pf.Close();
                        SetStatus(string.Format("批量生成完成：成功 {0} 个，失败 {1} 个 → {2}", ok, fail, dir));
                        string msg = string.Format("语音已生成完成！\n\n成功：{0} 个{1}\n保存目录：\n{2}\n\n是否打开文件夹？",
                            ok, fail > 0 ? "\n失败：" + fail + " 个" : "", dir);
                        if (MessageBox.Show(this, msg, "生成完成", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            try { Process.Start("explorer.exe", "\"" + dir + "\""); } catch { }
                        }
                    });
                }
                catch { }
            });
            t.IsBackground = true;
            t.Start();
        }

        void DownloadTts()
        {
            var pf = new ProgressForm();
            pf.Show(this);
            try
            {
                Tts.EnsurePiper(delegate (string msg, int pct) { pf.Set(msg, pct); Application.DoEvents(); });
                Tts.EnsureModel("en_US-lessac-medium", delegate (string msg, int pct) { pf.Set(msg, pct); Application.DoEvents(); });
                Tts.EnsureModel("zh_CN-huayan-medium", delegate (string msg, int pct) { pf.Set(msg, pct); Application.DoEvents(); });
                pf.Set("完成", 100);
            }
            catch (Exception e)
            {
                MessageBox.Show(this, e.Message, "下载失败");
            }
            finally
            {
                pf.Close();
                InitVoices();
            }
        }

        void Export(string kind)
        {
            if (current == null) { MessageBox.Show(this, "请先选择一份试卷"); return; }
            string filter = kind == "docx" ? "Word 文档|*.docx" : "网页|*.html";
            string ext = kind == "docx" ? ".docx" : ".html";
            var dlg = new SaveFileDialog { Filter = filter, FileName = current.Id + ext };
            if (dlg.ShowDialog(this) != DialogResult.OK) return;
            try
            {
                if (kind == "docx") Exporter.Docx(current, dlg.FileName);
                else File.WriteAllText(dlg.FileName, Exporter.Html(current), new UTF8Encoding(true));
                SetStatus("已导出: " + dlg.FileName);
            }
            catch (Exception e)
            {
                MessageBox.Show(this, e.Message, "导出失败");
            }
        }
    }

    class ProgressForm : Form
    {
        Label lbl;
        ProgressBar bar;

        public ProgressForm()
        {
            Text = "本地语音模型";
            Width = 480; Height = 150;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            ControlBox = false;
            ShowInTaskbar = false;
            Font = new Font("Microsoft YaHei UI", 9f);
            lbl = new Label { Text = "准备中…", Location = new Point(16, 20), Width = 430, Height = 20 };
            bar = new ProgressBar { Location = new Point(16, 56), Width = 430, Height = 22, Minimum = 0, Maximum = 100 };
            Controls.Add(lbl);
            Controls.Add(bar);
        }

        public void Set(string msg, int pct)
        {
            lbl.Text = msg;
            bar.Value = Math.Max(0, Math.Min(100, pct));
            Refresh();
        }
    }

    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

            // 命令行模式: --say <文本> <输出wav> [voiceId]
            if (args.Length >= 3 && args[0] == "--say")
            {
                string sayLog = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "say.log");
                try
                {
                    double sayRate = 1.0;
                    if (args.Length > 4) { double p; if (double.TryParse(args[4], out p) && p >= 50 && p <= 200) sayRate = p / 100.0; }
                    Tts.Synthesize(args[1], args.Length > 3 ? args[3] : "auto", sayRate, args[2]);
                    File.WriteAllText(sayLog, "OK " + args[2], new UTF8Encoding(false));
                    Environment.Exit(0);
                }
                catch (Exception e)
                {
                    File.WriteAllText(sayLog, "FAIL " + e.ToString(), new UTF8Encoding(false));
                    Environment.Exit(1);
                }
            }

            // 命令行模式: --fetch <试卷编号>   (供测试/脚本调用, 结果写 fetch.log)
            if (args.Length >= 2 && args[0] == "--fetch")
            {
                int fid;
                string logFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "fetch.log");
                var sb = new StringBuilder();
                try
                {
                    fid = int.Parse(args[1]);
                    string dir = Fetcher.Fetch(fid, delegate (string m) { sb.AppendLine(DateTime.Now.ToString("HH:mm:ss") + " " + m); });
                    sb.AppendLine("OK " + dir);
                    File.WriteAllText(logFile, sb.ToString(), new UTF8Encoding(false));
                    Environment.Exit(0);
                }
                catch (Exception e)
                {
                    sb.AppendLine("FAIL " + e.Message);
                    if (e.InnerException != null) sb.AppendLine("INNER " + e.InnerException.Message);
                    File.WriteAllText(logFile, sb.ToString(), new UTF8Encoding(false));
                    Environment.Exit(1);
                }
            }

            // 命令行模式: --export <试卷编号> <输出文件>
            if (args.Length >= 3 && args[0] == "--export")
            {
                string logFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "export.log");
                try
                {
                    int eid = int.Parse(args[1]);
                    string dir = Path.Combine(Paths.Pkg, eid.ToString());
                    if (!File.Exists(Path.Combine(dir, "data.json")))
                    {
                        foreach (var kv in PaperStore.Scan())
                            if (kv.Key == eid) dir = Path.GetDirectoryName(kv.Value[0]);
                    }
                    Paper pp = PaperStore.Load(dir, eid);
                    string outp = args[2];
                    if (outp.EndsWith(".docx", StringComparison.OrdinalIgnoreCase)) Exporter.Docx(pp, outp);
                    else if (outp.EndsWith(".html", StringComparison.OrdinalIgnoreCase)) File.WriteAllText(outp, Exporter.Html(pp), new UTF8Encoding(true));
                    else File.WriteAllText(outp, Exporter.Md(pp), new UTF8Encoding(false));
                    File.WriteAllText(logFile, "OK " + outp + "\r\n", new UTF8Encoding(false));
                    Environment.Exit(0);
                }
                catch (Exception e)
                {
                    File.WriteAllText(logFile, "FAIL " + e.Message, new UTF8Encoding(false));
                    Environment.Exit(1);
                }
            }

            // 命令行模式: --batch <试卷编号> <输出目录> [voiceId]
            if (args.Length >= 3 && args[0] == "--batch")
            {
                string log = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "batch.log");
                var sb = new StringBuilder();
                try
                {
                    int bpid = int.Parse(args[1]);
                    string dir = args[2];
                    Directory.CreateDirectory(dir);
                    string dirPaper = Path.Combine(Paths.Pkg, bpid.ToString());
                    if (!File.Exists(Path.Combine(dirPaper, "data.json")))
                    {
                        foreach (var kv in PaperStore.Scan())
                            if (kv.Key == bpid) dirPaper = Path.GetDirectoryName(kv.Value[0]);
                    }
                    Paper pp = PaperStore.Load(dirPaper, bpid);
                    string voice = args.Length > 3 ? args[3] : "auto";
                    double batchRate = 1.0;
                    if (args.Length > 4) { double bp; if (double.TryParse(args[4], out bp) && bp >= 50 && bp <= 200) batchRate = bp / 100.0; }
                    int n = 1, ok = 0;
                    foreach (Question q in pp.AllQuestions())
                    {
                        string body = q.Variants.Count > 0 ? q.Variants[0] : q.Answer;
                        if (string.IsNullOrEmpty(body)) { n++; continue; }
                        string name = string.Format("{0:00}_{1}.wav", n, q.Head);
                        foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
                        string path = Path.Combine(dir, name);
                        try { Tts.Synthesize(body, voice, batchRate, path); ok++; sb.AppendLine("OK " + name); }
                        catch (Exception e) { sb.AppendLine("FAIL " + name + " " + e.Message); }
                        n++;
                    }
                    sb.AppendLine("DONE " + ok + "/" + (n - 1));
                    File.WriteAllText(log, sb.ToString(), new UTF8Encoding(false));
                    Environment.Exit(0);
                }
                catch (Exception e)
                {
                    File.WriteAllText(log, "FAIL " + e, new UTF8Encoding(false));
                    Environment.Exit(1);
                }
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            var f = new MainForm();
            int pid;
            if (args.Length > 0 && int.TryParse(args[0].Trim(), out pid)) { f.want = pid; f.RefreshListPublic(); }
            Application.Run(f);
        }
    }
}
