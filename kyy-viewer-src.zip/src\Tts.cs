using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Speech.Synthesis;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace KyyViewer
{
    class VoiceInfo
    {
        public string Id;
        public string Name;
        public string Engine;     // piper / sapi
        public string Model;      // onnx path
        public string SapiName;
        public string Lang;

        public override string ToString() { return Name; }
    }

    /// <summary>本地语音合成: Piper 神经语音(离线) + Windows SAPI(兜底)</summary>
    static class Tts
    {
        public static string Root = Path.Combine(Paths.Root, "tts");
        public static string PiperDir { get { return Path.Combine(Root, "piper"); } }
        public static string PiperExe { get { return Path.Combine(PiperDir, "piper.exe"); } }
        public static string ModelDir { get { return Path.Combine(Root, "models"); } }
        public static string AudioDir { get { return Path.Combine(Paths.Root, "audio"); } }

        /// <summary>语音输出目录: 默认在 exe 所在目录下自动建 “答案语音\试卷号” 文件夹</summary>
        public static string OutRoot
        {
            get
            {
                string dir = Path.Combine(Paths.ExeDir, "答案语音");
                try
                {
                    Directory.CreateDirectory(dir);
                    return dir;
                }
                catch
                {
                    Directory.CreateDirectory(AudioDir);
                    return AudioDir;
                }
            }
        }

        public static string OutDir(int paperId)
        {
            string dir = Path.Combine(OutRoot, paperId.ToString());
            Directory.CreateDirectory(dir);
            return dir;
        }

        public const string PiperZip = "https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_windows_amd64.zip";
        public const string HfBase = "https://hf-mirror.com/rhasspy/piper-voices/resolve/main/";

        public static readonly string[] PiperMirrors = {
            "https://gh-proxy.com/https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_windows_amd64.zip",
            "https://ghproxy.net/https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_windows_amd64.zip",
            "https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_windows_amd64.zip"
        };

        public static readonly string[] ModelMirrors = {
            "https://hf-mirror.com/rhasspy/piper-voices/resolve/main/",
            "https://huggingface.co/rhasspy/piper-voices/resolve/main/"
        };

        // 相对 piper-voices 仓库的路径
        public static readonly Dictionary<string, string[]> ModelFiles = new Dictionary<string, string[]>
        {
            { "en_US-lessac-medium", new[] { "en/en_US/lessac/medium/en_US-lessac-medium.onnx", "en/en_US/lessac/medium/en_US-lessac-medium.onnx.json" } },
            { "zh_CN-huayan-medium", new[] { "zh/zh_CN/huayan/medium/zh_CN-huayan-medium.onnx", "zh/zh_CN/huayan/medium/zh_CN-huayan-medium.onnx.json" } },
        };

        public static string ModelPath(string key) { return Path.Combine(ModelDir, key + ".onnx"); }
        public static bool ModelReady(string key) { return File.Exists(ModelPath(key)) && File.Exists(ModelPath(key) + ".json"); }
        public static bool PiperReady { get { return File.Exists(PiperExe); } }

        // ---------- 声音列表 ----------
        public static List<VoiceInfo> Voices()
        {
            var list = new List<VoiceInfo>();
            if (PiperReady && ModelReady("en_US-lessac-medium"))
                list.Add(new VoiceInfo { Id = "piper:en", Name = "本地神经语音 · 英文女声 (Lessac)", Engine = "piper", Model = ModelPath("en_US-lessac-medium"), Lang = "en" });
            if (PiperReady && ModelReady("zh_CN-huayan-medium"))
                list.Add(new VoiceInfo { Id = "piper:zh", Name = "本地神经语音 · 中文女声 (Huayan)", Engine = "piper", Model = ModelPath("zh_CN-huayan-medium"), Lang = "zh" });
            list.Add(new VoiceInfo { Id = "auto", Name = "自动（按文字选中英文）", Engine = "auto", Lang = "auto" });
            try
            {
                using (var s = new SpeechSynthesizer())
                {
                    foreach (var v in s.GetInstalledVoices())
                    {
                        if (!v.Enabled) continue;
                        var info = v.VoiceInfo;
                        list.Add(new VoiceInfo { Id = "sapi:" + info.Name, Name = "系统语音 · " + info.Name, Engine = "sapi", SapiName = info.Name, Lang = info.Culture.ThreeLetterISOLanguageName });
                    }
                }
            }
            catch { }
            return list;
        }

        public static bool IsCjk(string text)
        {
            int cjk = 0, total = 0;
            foreach (char c in text)
            {
                if (char.IsWhiteSpace(c)) continue;
                total++;
                if (c >= 0x4E00 && c <= 0x9FFF) cjk++;
            }
            return total > 0 && cjk * 100 / total >= 15;
        }

        // ---------- 合成 ----------
        public static string Synthesize(string text, string voiceId, double rate, string outWav)
        {
            if (string.IsNullOrEmpty(text)) throw new Exception("没有可朗读的文字");
            Directory.CreateDirectory(Path.GetDirectoryName(outWav));
            VoiceInfo v = Resolve(voiceId, text);
            if (v.Engine == "piper") RunPiper(text, v.Model, rate, outWav);
            else RunSapi(text, v.SapiName, rate, outWav);
            if (!File.Exists(outWav) || new FileInfo(outWav).Length < 1000)
                throw new Exception("语音合成失败：输出为空");
            return outWav;
        }

        static VoiceInfo Resolve(string id, string text)
        {
            var all = Voices();
            if (id != null && id.StartsWith("sapi:"))
            {
                foreach (var v in all) if (v.Id == id) return v;
            }
            bool cjk = IsCjk(text);
            string want = cjk ? "piper:zh" : "piper:en";
            foreach (var v in all) if (v.Id == want) return v;
            // 回退: 任一 piper, 再回退 sapi
            foreach (var v in all) if (v.Engine == "piper") return v;
            foreach (var v in all) if (v.Engine == "sapi") return v;
            throw new Exception("没有可用的语音，请先下载本地语音模型");
        }

        static void RunPiper(string text, string model, double rate, string outWav)
        {
            double lengthScale = 1.0 / Math.Max(0.5, Math.Min(2.0, rate));
            var psi = new ProcessStartInfo
            {
                FileName = PiperExe,
                Arguments = "-m \"" + model + "\" -f \"" + outWav + "\" --length_scale " + lengthScale.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture),
                WorkingDirectory = PiperDir,
                UseShellExecute = false,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = new UTF8Encoding(false),
                StandardErrorEncoding = new UTF8Encoding(false),
            };
            using (var p = Process.Start(psi))
            {
                p.StandardInput.Write(text + "\n");
                p.StandardInput.Close();
                string err = p.StandardError.ReadToEnd();
                p.StandardOutput.ReadToEnd();
                if (!p.WaitForExit(120000))
                {
                    try { p.Kill(); } catch { }
                    throw new Exception("语音合成超时");
                }
                if (p.ExitCode != 0)
                    throw new Exception("piper 失败(" + p.ExitCode + "): " + Trim(err, 300));
            }
        }

        static void RunSapi(string text, string sapiName, double rate, string outWav)
        {
            using (var s = new SpeechSynthesizer())
            {
                if (!string.IsNullOrEmpty(sapiName)) s.SelectVoice(sapiName);
                int r = (int)Math.Round((rate - 1.0) * 10);
                s.Rate = Math.Max(-10, Math.Min(10, r));
                s.SetOutputToWaveFile(outWav);
                s.Speak(text);
                s.SetOutputToNull();
            }
        }

        static string Trim(string s, int n)
        {
            if (string.IsNullOrEmpty(s)) return "";
            s = s.Trim();
            return s.Length <= n ? s : s.Substring(0, n) + "…";
        }

        // ---------- 下载 ----------
        public static void EnsurePiper(Action<string, int> progress)
        {
            Directory.CreateDirectory(Root);
            if (PiperReady) return;
            string tmp = Path.Combine(Root, "piper.zip");
            Exception last = null;
            foreach (string url in PiperMirrors)
            {
                try
                {
                    progress("下载语音引擎…", 0);
                    Download(url, tmp, delegate (int p) { progress("下载语音引擎…", p * 85 / 100); });
                    progress("解压语音引擎…", 90);
                    if (Directory.Exists(PiperDir)) Directory.Delete(PiperDir, true);
                    ZipFile.ExtractToDirectory(tmp, Root);
                    string inner = Path.Combine(Root, "piper");
                    if (!File.Exists(Path.Combine(inner, "piper.exe")))
                    {
                        foreach (string d in Directory.GetDirectories(Root))
                            if (File.Exists(Path.Combine(d, "piper.exe"))) { inner = d; break; }
                    }
                    if (!File.Exists(Path.Combine(inner, "piper.exe"))) throw new Exception("压缩包内未找到 piper.exe");
                    File.Delete(tmp);
                    progress("语音引擎就绪", 100);
                    return;
                }
                catch (Exception e) { last = e; }
            }
            throw new Exception("下载语音引擎失败: " + (last != null ? last.Message : "未知错误"));
        }

        public static void EnsureModel(string key, Action<string, int> progress)
        {
            Directory.CreateDirectory(ModelDir);
            if (ModelReady(key)) return;
            Exception last = null;
            foreach (string baseUrl in ModelMirrors)
            {
                try
                {
                    string[] rels = ModelFiles[key];
                    for (int i = 0; i < rels.Length; i++)
                    {
                        string target = Path.Combine(ModelDir, key + (i == 0 ? ".onnx" : ".onnx.json"));
                        progress("下载语音模型 " + key + "…", i * 50);
                        Download(baseUrl + rels[i], target, delegate (int p) { progress("下载语音模型 " + key + "…", i * 50 + p / 2); });
                    }
                    if (!ModelReady(key)) throw new Exception("模型文件不完整");
                    progress("模型就绪 " + key, 100);
                    return;
                }
                catch (Exception e) { last = e; }
            }
            throw new Exception("下载模型失败: " + (last != null ? last.Message : "未知错误"));
        }

        static void Download(string url, string target, Action<int> pct)
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            using (var wc = new WebClient())
            {
                wc.Headers.Add("User-Agent", "Mozilla/5.0");
                wc.DownloadProgressChanged += delegate (object s, DownloadProgressChangedEventArgs e) { if (pct != null) pct(e.ProgressPercentage); };
                wc.DownloadFileAsync(new Uri(url), target);
                while (wc.IsBusy) Application.DoEvents();
            }
            if (!File.Exists(target) || new FileInfo(target).Length < 1000) throw new Exception("下载失败");
        }

        // ---------- 播放 ----------
        static System.Media.SoundPlayer player;
        public static void Play(string wav)
        {
            Stop();
            player = new System.Media.SoundPlayer(wav);
            player.Play();
        }
        public static void Stop()
        {
            if (player != null)
            {
                try { player.Stop(); } catch { }
                player = null;
            }
        }
    }
}
