# Build the viewer exe with the in-box .NET Framework compiler (no SDK required).
# Output: ..\<viewer name>.exe  (name built from code points to stay encoding-proof)
$ErrorActionPreference = 'Stop'
$src = $PSScriptRoot
$parent = Split-Path $src -Parent

# "Kou Yu Yi Da An Cha Kan Qi" -> 口语易答案查看器.exe
$outName = (-join ([char]0x53E3,[char]0x8BED,[char]0x6613,[char]0x7B54,[char]0x6848,[char]0x67E5,[char]0x770B,[char]0x5668)) + '.exe'
$out = Join-Path $parent $outName

$fw = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$csc = Join-Path $fw 'csc.exe'
$speech = 'C:\Windows\Microsoft.NET\assembly\GAC_MSIL\System.Speech\v4.0_4.0.0.0__31bf3856ad364e35\System.Speech.dll'

if (-not (Test-Path $csc)) { throw "csc.exe not found: $csc" }

$refs = @(
  'System.dll','System.Core.dll','System.Windows.Forms.dll','System.Drawing.dll',
  'System.Web.Extensions.dll','System.Net.WebSockets.dll','System.Net.WebSockets.Client.dll',
  'System.IO.Compression.dll','System.IO.Compression.FileSystem.dll'
) | ForEach-Object { '/r:' + (Join-Path $fw $_) }

$icon = Join-Path $src 'app.ico'
$iconArg = @()
if (Test-Path $icon) { $iconArg = @('/win32icon:' + $icon) }

& $csc /nologo /target:winexe /platform:anycpu /optimize+ `
  /r:"$speech" @refs @iconArg `
  /out:"$out" `
  (Join-Path $src 'KyyViewer.cs') (Join-Path $src 'Tts.cs') (Join-Path $src 'AudioOut.cs')

if ($LASTEXITCODE -ne 0) { throw "compile failed (exit $LASTEXITCODE)" }
Write-Host ("OK -> " + $out)
