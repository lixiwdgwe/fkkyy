using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

namespace KyyViewer
{
    /// <summary>把 wav 播放到指定输出设备(含虚拟声卡 CABLE Input 之类), 用于“喂”给麦克风</summary>
    static class AudioOut
    {
        [StructLayout(LayoutKind.Sequential)]
        struct WAVEFORMATEX
        {
            public ushort wFormatTag;
            public ushort nChannels;
            public uint nSamplesPerSec;
            public uint nAvgBytesPerSec;
            public ushort nBlockAlign;
            public ushort wBitsPerSample;
            public ushort cbSize;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct WAVEHDR
        {
            public IntPtr lpData;
            public uint dwBufferLength;
            public uint dwBytesRecorded;
            public IntPtr dwUser;
            public uint dwFlags;
            public uint dwLoops;
            public IntPtr lpNext;
            public IntPtr reserved;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct WAVEOUTCAPS
        {
            public ushort wMid;
            public ushort wPid;
            public uint vDriverVersion;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string szPname;
            public uint dwFormats;
            public ushort wChannels;
            public ushort wReserved1;
            public uint dwSupport;
        }

        delegate void WaveCallback(IntPtr hwo, uint msg, IntPtr instance, IntPtr p1, IntPtr p2);

        const uint MM_WOM_DONE = 0x3BD;
        const uint WOM_OPEN = 0x3BB;
        const uint WOM_CLOSE = 0x3BC;
        const uint CALLBACK_FUNCTION = 0x00030000;
        const int WAVE_MAPPER = -1;

        [DllImport("winmm.dll")] static extern uint waveOutGetNumDevs();
        [DllImport("winmm.dll", CharSet = CharSet.Unicode)] static extern uint waveOutGetDevCaps(IntPtr uDeviceID, ref WAVEOUTCAPS caps, int size);
        [DllImport("winmm.dll")] static extern uint waveOutOpen(out IntPtr hwo, int deviceId, ref WAVEFORMATEX fmt, WaveCallback cb, IntPtr inst, uint flags);
        [DllImport("winmm.dll")] static extern uint waveOutPrepareHeader(IntPtr hwo, IntPtr hdr, int size);
        [DllImport("winmm.dll")] static extern uint waveOutWrite(IntPtr hwo, IntPtr hdr, int size);
        [DllImport("winmm.dll")] static extern uint waveOutReset(IntPtr hwo);
        [DllImport("winmm.dll")] static extern uint waveOutUnprepareHeader(IntPtr hwo, IntPtr hdr, int size);
        [DllImport("winmm.dll")] static extern uint waveOutClose(IntPtr hwo);

        public class Device
        {
            public int Id;          // -1 = 默认设备
            public string Name;
            public override string ToString() { return Name; }
        }

        public static List<Device> Devices()
        {
            var list = new List<Device>();
            list.Add(new Device { Id = WAVE_MAPPER, Name = "默认播放设备（扬声器）" });
            uint n = waveOutGetNumDevs();
            for (uint i = 0; i < n; i++)
            {
                var caps = new WAVEOUTCAPS();
                if (waveOutGetDevCaps(new IntPtr(i), ref caps, Marshal.SizeOf(typeof(WAVEOUTCAPS))) == 0)
                    list.Add(new Device { Id = (int)i, Name = caps.szPname });
            }
            return list;
        }

        // ---- 播放状态 ----
        static Thread thread;
        static volatile bool stopFlag;
        static IntPtr curHandle = IntPtr.Zero;
        static IntPtr curHeader = IntPtr.Zero;
        static WaveCallback callback;      // 保持委托存活
        static ManualResetEvent done;

        public static string LastError = "";
        public static bool Playing { get { return thread != null && thread.IsAlive; } }

        /// <summary>播放结束(正常播完或被打断)时触发, 在后台线程上调用</summary>
        public static event Action Finished;

        public static void Play(string wavPath, int deviceId)
        {
            Stop();
            stopFlag = false;
            thread = new Thread(delegate () { PlayWorker(wavPath, deviceId); });
            thread.IsBackground = true;
            thread.Start();
        }

        static void PlayWorker(string wavPath, int deviceId)
        {
            byte[] data;
            WAVEFORMATEX fmt;
            int dataLen;
            try
            {
                if (!ReadWav(wavPath, out fmt, out data, out dataLen)) { LastError = "不是可播放的 PCM wav"; return; }
            }
            catch (Exception e) { LastError = e.Message; return; }

            IntPtr hwo = IntPtr.Zero;
            IntPtr hdrPtr = IntPtr.Zero;
            IntPtr dataPtr = IntPtr.Zero;
            try
            {
                done = new ManualResetEvent(false);
                callback = delegate (IntPtr h, uint msg, IntPtr inst, IntPtr p1, IntPtr p2)
                {
                    if (msg == MM_WOM_DONE && done != null) done.Set();
                };
                uint r = waveOutOpen(out hwo, deviceId, ref fmt, callback, IntPtr.Zero, CALLBACK_FUNCTION);
                if (r != 0) { LastError = "打开音频设备失败 (code " + r + ")"; return; }
                curHandle = hwo;

                dataPtr = Marshal.AllocHGlobal(dataLen);
                Marshal.Copy(data, 0, dataPtr, dataLen);

                var hdr = new WAVEHDR();
                hdr.lpData = dataPtr;
                hdr.dwBufferLength = (uint)dataLen;
                hdrPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(WAVEHDR)));
                Marshal.StructureToPtr(hdr, hdrPtr, false);
                curHeader = hdrPtr;

                if (waveOutPrepareHeader(hwo, hdrPtr, Marshal.SizeOf(typeof(WAVEHDR))) != 0) { LastError = "准备音频缓冲失败"; return; }
                if (waveOutWrite(hwo, hdrPtr, Marshal.SizeOf(typeof(WAVEHDR))) != 0) { LastError = "写入音频设备失败"; return; }

                // 等待播放完成（最多 10 分钟），期间可被 Stop 打断
                double seconds = dataLen / (double)(fmt.nAvgBytesPerSec == 0 ? 44100 : fmt.nAvgBytesPerSec);
                var deadline = DateTime.UtcNow.AddSeconds(seconds + 10);
                while (!stopFlag && DateTime.UtcNow < deadline)
                {
                    if (done.WaitOne(100)) break;
                }
            }
            catch (Exception e) { LastError = e.Message; }
            finally
            {
                try { if (hwo != IntPtr.Zero) waveOutReset(hwo); } catch { }
                try { if (hwo != IntPtr.Zero && hdrPtr != IntPtr.Zero) waveOutUnprepareHeader(hwo, hdrPtr, Marshal.SizeOf(typeof(WAVEHDR))); } catch { }
                try { if (hwo != IntPtr.Zero) waveOutClose(hwo); } catch { }
                try { if (hdrPtr != IntPtr.Zero) Marshal.FreeHGlobal(hdrPtr); } catch { }
                try { if (dataPtr != IntPtr.Zero) Marshal.FreeHGlobal(dataPtr); } catch { }
                curHandle = IntPtr.Zero;
                curHeader = IntPtr.Zero;
                var f = Finished;
                if (f != null) { try { f(); } catch { } }
            }
        }

        public static void Stop()
        {
            stopFlag = true;
            try { if (curHandle != IntPtr.Zero) waveOutReset(curHandle); } catch { }
            try { if (done != null) done.Set(); } catch { }
            if (thread != null)
            {
                try { thread.Join(1500); } catch { }
                thread = null;
            }
        }

        static bool ReadWav(string path, out WAVEFORMATEX fmt, out byte[] data, out int dataLen)
        {
            fmt = new WAVEFORMATEX();
            data = null; dataLen = 0;
            byte[] all = File.ReadAllBytes(path);
            if (all.Length < 44 || all[0] != 'R' || all[1] != 'I' || all[2] != 'F' || all[3] != 'F') return false;
            int pos = 12;
            while (pos + 8 <= all.Length)
            {
                string id = "" + (char)all[pos] + (char)all[pos + 1] + (char)all[pos + 2] + (char)all[pos + 3];
                int size = BitConverter.ToInt32(all, pos + 4);
                int body = pos + 8;
                if (id == "fmt ")
                {
                    fmt.wFormatTag = BitConverter.ToUInt16(all, body);
                    fmt.nChannels = BitConverter.ToUInt16(all, body + 2);
                    fmt.nSamplesPerSec = BitConverter.ToUInt32(all, body + 4);
                    fmt.nAvgBytesPerSec = BitConverter.ToUInt32(all, body + 8);
                    fmt.nBlockAlign = BitConverter.ToUInt16(all, body + 12);
                    fmt.wBitsPerSample = BitConverter.ToUInt16(all, body + 14);
                    fmt.cbSize = 0;
                }
                else if (id == "data")
                {
                    dataLen = Math.Min(size, all.Length - body);
                    data = new byte[dataLen];
                    Buffer.BlockCopy(all, body, data, 0, dataLen);
                    return fmt.nChannels > 0 && fmt.nSamplesPerSec > 0;
                }
                pos = body + size + (size & 1);
            }
            return false;
        }
    }
}
